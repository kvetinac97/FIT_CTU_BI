//
//  ProfileViewController.swift
//  FITstagram
//
//  Created by Thats Me on 20/10/2020.
//

import UIKit

class ProfileViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad();
        navigationItem.title = "Profile"
    }
    
    @IBOutlet weak var username: UILabel!
    
    @IBAction func editUsername(_ sender: Any) {
        let alertController = UIAlertController(title: "Change username", message: "Changing username will sign you in as", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { alert -> Void in
            let textField = alertController.textFields![0] as UITextField
            self.username.text = textField.text
        }))
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        alertController.addTextField(configurationHandler: {(textField : UITextField!) -> Void in
            textField.text = self.username.text
        })
        self.present(alertController, animated: true, completion: nil)
    }
    
}
