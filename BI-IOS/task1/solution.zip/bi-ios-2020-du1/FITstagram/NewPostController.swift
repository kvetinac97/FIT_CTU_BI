//
//  NewPostController.swift
//  FITstagram
//
//  Created by Thats Me on 20/10/2020.
//

import UIKit

class NewPostController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var createButton: UIButton!
    
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var location: UIButton!
    
    @IBOutlet weak var postImage: UIImageView!
    @IBOutlet weak var postSelect: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cancelButton.addTarget(self, action: #selector(cancelTap), for: .touchUpInside)
        createButton.addTarget(self, action: #selector(createTap), for: .touchUpInside)
        
        textView.layer.borderWidth = 1
        location.addTarget(self, action: #selector(locationTap), for: .touchUpInside)
        
        postImage.layer.borderWidth = 1
        postSelect.addTarget(self, action: #selector(postTap), for: .touchUpInside)
    }
    
    @objc private func cancelTap () {
        print("cancel tapped")
    }
    @objc private func createTap () {
        print(textView.text)
        textView.endEditing(true)
    }
    @objc private func locationTap () {
        print("location tapped")
    }
    @objc private func postTap () {
        let vc = UIImagePickerController()
        vc.sourceType = .camera
        vc.allowsEditing = true
        vc.delegate = self
        present(vc, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)

        guard let image = info[.editedImage] as? UIImage else {
            print("No image found")
            return
        }

        // print out the image size as a test
        postImage.image = image
        postImage.backgroundColor = nil
        postSelect.isHidden = true
    }
    
}
