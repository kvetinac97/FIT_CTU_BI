//
//  CVUT_SwiftUI_1App.swift
//  CVUT-SwiftUI-1
//
//  Created by Jan Kodeš on 04.12.2020.
//

import SwiftUI

@main
struct CVUT_SwiftUI_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
