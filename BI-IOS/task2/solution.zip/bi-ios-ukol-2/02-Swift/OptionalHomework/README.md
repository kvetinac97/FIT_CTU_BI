# Zadání

Pokud si chcete se Swiftem trochu pohrát, doporučuju si vyzkoušet naprogramovat pár úloh.

### 1. Projděte si i témata, která se nestihla na hodině

[Tady](../) je playground ze cvičení

Pokud Vám něco z playgroundu nebude jasné, nebojte se napsat na Slack.

### 2. Podívejte se na úlohy v Homework.playground

V Playgroundu jsou tři stránky s několika úkoly. Pokud Vám něco z playgroundu nebude jasné, nebojte se napsat na Slack.