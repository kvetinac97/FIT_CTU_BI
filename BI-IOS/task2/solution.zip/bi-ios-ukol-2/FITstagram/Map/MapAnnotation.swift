//
//  MapAnnotation.swift
//  FITstagram
//
//  Created by Thats Me on 12.12.2020.
//

import Foundation
import MapKit

final class MapAnnotation: NSObject, MKAnnotation {
    
    let coordinate: CLLocationCoordinate2D
    let postId: Int?
    let title: String?
    let subtitle: String?
    public let image: UIImage?
    
    init (coordinate: CLLocationCoordinate2D, post: Post) {
        self.coordinate = coordinate
        self.postId = post.id
        self.title = post.author
        self.subtitle = post.location
        self.image = post.image
    }
    
}
