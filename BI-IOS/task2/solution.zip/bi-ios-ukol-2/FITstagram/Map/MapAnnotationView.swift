//
//  MapAnnotationView.swift
//  FITstagram
//
//  Created by Thats Me on 12.12.2020.
//

import Foundation
import UIKit
import MapKit

final class MapAnnotationView: MKMarkerAnnotationView {
    
    var subtitle: String? {
        get { subtitleLabel.text }
        set { subtitleLabel.text = newValue }
    }

    var postImage: UIImage? {
        get { postImageView.image }
        set { postImageView.image = newValue }
    }
    
    var postId: Int?
        
    private weak var postImageView: UIImageView!
    private weak var subtitleLabel: UILabel!
    
    override init(annotation: MKAnnotation?, reuseIdentifier: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        translatesAutoresizingMaskIntoConstraints = false
        glyphImage = UIImage(systemName: "camera")
        
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            view.heightAnchor.constraint(greaterThanOrEqualToConstant: 50),
            view.widthAnchor.constraint(greaterThanOrEqualToConstant: 50),
        ]);
        
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 12)
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            label.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            label.topAnchor.constraint(equalTo: view.topAnchor)
        ])
        self.subtitleLabel = label
        
        let postImageView = UIImageView()
        postImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(postImageView)
        
        NSLayoutConstraint.activate([
            postImageView.heightAnchor.constraint(equalToConstant: 50),
            postImageView.widthAnchor.constraint(equalToConstant: 50),
            postImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            postImageView.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 10),
            postImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        self.postImageView = postImageView
        detailCalloutAccessoryView = view
        
        let chevronButton = UIButton(type: .detailDisclosure)
        let image = UIImage(systemName: "chevron.right")
        chevronButton.setImage(image, for: .normal)
        rightCalloutAccessoryView = chevronButton
    }
    
    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
