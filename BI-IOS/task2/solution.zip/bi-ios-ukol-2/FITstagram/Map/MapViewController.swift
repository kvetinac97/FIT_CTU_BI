//
//  MapViewController.swift
//  FITstagram
//
//  Created by Thats Me on 12.12.2020.
//

import Foundation
import UIKit
import MapKit

final class MapViewController: UIViewController {
    
    private weak var mapView: MKMapView!
    
    private var viewModel: MapViewModeling
    
    // MARK: - Initialization
    
    init(viewModel: MapViewModeling) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func loadView() {
        super.loadView()
        
        let mapView = MKMapView()
        mapView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mapView)
        NSLayoutConstraint.activate([
            mapView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mapView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            mapView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            mapView.topAnchor.constraint(equalTo: view.topAnchor),
        ])
        self.mapView = mapView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        
        mapView.register(MapAnnotationView.self, forAnnotationViewWithReuseIdentifier: "MapAnnotationView")
        
        viewModel.viewModelDidChange = { [weak self] viewModel in
            self?.showPostOnMap()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        viewModel.loadPhotos()
    }
    
    // MARK: - Private helpers
    
    private func showPostOnMap () {
        print("Test: loaded posts")
        
        // Ignore empty
        if viewModel.posts.isEmpty {
            return
        }
        
        var minLon = viewModel.posts.first!.lon!, maxLon = minLon,
            minLat = viewModel.posts.first!.lat!, maxLat = minLat
        
        for post in viewModel.posts {
            minLat = min(minLat, post.lat!)
            maxLat = max(maxLat, post.lat!)
            minLon = min(minLon, post.lon!)
            maxLon = max(maxLon, post.lon!)
            
            let mapAnnotation = MapAnnotation(
                coordinate: CLLocationCoordinate2D(latitude: post.lat!, longitude: post.lon!),
                post: post
            )
            
            mapView.addAnnotation(
                mapAnnotation
            )
        }
        
        mapView.setRegion(
            MKCoordinateRegion(
                center: CLLocationCoordinate2D(latitude: (minLat + maxLat) / 2, longitude: (minLon + maxLon) / 2),
                span: MKCoordinateSpan(latitudeDelta: (maxLat - minLat) * 1.5, longitudeDelta: (maxLon - minLon) * 1.5)
            ),
            animated: true
        )
    }
    
}
extension MapViewController: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard (annotation is MapAnnotation) else { return nil }

        let view = mapView.dequeueReusableAnnotationView(withIdentifier: "MapAnnotationView") as! MapAnnotationView
        let mapAnnotation = annotation as! MapAnnotation
        
        view.canShowCallout = true
        view.subtitle = mapAnnotation.subtitle
        view.postImage = mapAnnotation.image
        view.postId = mapAnnotation.postId
        
        return view
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        guard (view.annotation is MapAnnotation) else { return }
        mapView.setCenter(view.annotation!.coordinate, animated: true)
    }
    
    func mapView(_ mapView: MKMapView, annotationView: MKAnnotationView, calloutAccessoryControlTapped calloutAccesoryControlTapped: UIControl) {
        
        guard (annotationView is MapAnnotationView) else { return }
        if ( calloutAccesoryControlTapped != annotationView.rightCalloutAccessoryView ) {
            return
        }
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let id = (annotationView as! MapAnnotationView).postId!
        let controller = storyboard.instantiateViewController(identifier: "FeedViewController") {
            FeedViewController(coder: $0, viewModel: FeedViewModel(postId: id))
        }
        
        let navigationController = UINavigationController(rootViewController: controller)
        present(navigationController, animated: true)
    }
    
}
